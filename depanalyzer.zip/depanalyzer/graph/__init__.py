"""Graph module initialization."""
