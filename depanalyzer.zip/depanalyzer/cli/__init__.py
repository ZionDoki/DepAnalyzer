"""CLI module for depanalyzer commands."""
