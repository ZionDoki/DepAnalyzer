"""Runtime module for transaction, workspace, and execution management."""
